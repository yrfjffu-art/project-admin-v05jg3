# FHL Calculator — Android Studio Project

A native Android calculator written in Kotlin. It works offline and includes:
- Addition, subtraction, multiplication, division and remainder
- Decimal numbers, parentheses-ready calculation parser, sign toggle
- Clear and delete controls
- Dark neon interface

## Open in Android Studio
1. Extract this ZIP.
2. In Android Studio choose **Open** and select the extracted `FHL_Calculator_Android_Studio` folder.
3. Allow Gradle sync and install the Android SDK platform 35 if Android Studio asks.
4. Run the `app` configuration on an emulator or Android phone.

## Build APK
In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.fhl.calculator`
Minimum Android: 6.0 (API 23)
Compile SDK: 35
JDK: 17

This is a real native Android Studio project, not a website or WebView wrapper.
