package com.fhl.calculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class MainActivity : Activity() {
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private var expression = ""
    private var justEvaluated = false

    private val bg = Color.rgb(9, 13, 24)
    private val panel = Color.rgb(18, 25, 42)
    private val cyan = Color.rgb(98, 230, 255)
    private val white = Color.rgb(239, 245, 255)
    private val muted = Color.rgb(139, 155, 180)
    private val operator = Color.rgb(31, 49, 70)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "FHL  /  CALCULATOR"
            textSize = 14f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = .12f
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(42), 1f))
        val clearAll = TextView(this).apply {
            text = "CLEAR"
            textSize = 12f
            setTextColor(muted)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(4), 0)
            setOnClickListener { expression = ""; justEvaluated = false; refresh() }
        }
        header.addView(clearAll)
        root.addView(header)

        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(panel, 24)
        }
        expressionView = TextView(this).apply {
            text = ""
            textSize = 22f
            setTextColor(muted)
            gravity = Gravity.END
            maxLines = 2
        }
        resultView = TextView(this).apply {
            text = "0"
            textSize = 44f
            setTextColor(white)
            gravity = Gravity.END
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            maxLines = 1
        }
        display.addView(expressionView)
        display.addView(resultView)
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1.15f).apply {
            topMargin = dp(18); bottomMargin = dp(18)
        })

        val rows = listOf(
            listOf("AC", "DEL", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("±", "0", ".", "=")
        )
        rows.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { label ->
                val b = Button(this).apply {
                    text = label
                    textSize = if (label.length > 1) 17f else 22f
                    isAllCaps = false
                    typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    setTextColor(when {
                        label == "=" -> bg
                        label in listOf("÷", "×", "−", "+", "%") -> cyan
                        label in listOf("AC", "DEL", "±") -> muted
                        else -> white
                    })
                    background = rounded(
                        when {
                            label == "=" -> cyan
                            label in listOf("÷", "×", "−", "+", "%") -> operator
                            label in listOf("AC", "DEL", "±") -> panel
                            else -> Color.rgb(22, 30, 48)
                        }, 18
                    )
                    setPadding(0, 0, 0, 0)
                    stateListAnimator = null
                    setOnClickListener { onKey(label) }
                }
                line.addView(b, LinearLayout.LayoutParams(0, dp(68), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            root.addView(line)
        }

        val footer = TextView(this).apply {
            text = "SIMPLE  •  FAST  •  OFFLINE"
            textSize = 10f
            letterSpacing = .18f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(85, 104, 132))
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun onKey(key: String) {
        when (key) {
            "AC" -> { expression = ""; justEvaluated = false }
            "DEL" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1); justEvaluated = false }
            "=" -> {
                if (expression.isNotBlank()) {
                    try {
                        val answer = CalculatorParser(expression).parse()
                        expression = format(answer)
                        justEvaluated = true
                    } catch (_: Exception) {
                        resultView.text = "Error"
                        return
                    }
                }
            }
            "±" -> {
                if (expression.isNotEmpty()) {
                    val match = Regex("""(\d+(?:\.\d+)?)$""").find(expression)
                    if (match != null) {
                        val start = match.range.first
                        val prefix = expression.substring(0, start)
                        val value = match.value
                        expression = if (prefix.endsWith("-") && (prefix.length == 1 || "+−×÷(".contains(prefix[prefix.length - 2]))) {
                            prefix.dropLast(1) + value
                        } else prefix + "−" + value
                    }
                }
            }
            else -> {
                if (justEvaluated && (key.firstOrNull()?.isDigit() == true || key == ".")) expression = ""
                justEvaluated = false
                val token = when (key) { "÷" -> "/"; "×" -> "*"; "−" -> "-"; else -> key }
                if (key == "." && expression.split(Regex("[+\\-*/%()]")).last().contains(".")) return
                expression += token
            }
        }
        refresh()
    }

    private fun refresh() {
        expressionView.text = expression.replace("/", "÷").replace("*", "×").replace("-", "−")
        if (!justEvaluated) resultView.text = if (expression.isEmpty()) "0" else expressionView.text
    }

    private fun format(value: Double): String {
        if (!value.isFinite()) throw ArithmeticException()
        val bd = BigDecimal.valueOf(value).round(MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros()
        return bd.toPlainString()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

private class CalculatorParser(private val input: String) {
    private var pos = 0
    fun parse(): Double {
        val value = expression()
        skip()
        if (pos != input.length) error("Unexpected input")
        return value
    }
    private fun expression(): Double {
        var value = term()
        while (true) {
            skip()
            value = when {
                take('+') -> value + term()
                take('-') -> value - term()
                else -> return value
            }
        }
    }
    private fun term(): Double {
        var value = factor()
        while (true) {
            skip()
            value = when {
                take('*') -> value * factor()
                take('/') -> value / factor()
                take('%') -> value % factor()
                else -> return value
            }
        }
    }
    private fun factor(): Double {
        skip()
        if (take('+')) return factor()
        if (take('-')) return -factor()
        if (take('(')) {
            val v = expression()
            skip()
            if (!take(')')) error("Missing )")
            return v
        }
        val start = pos
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
        if (start == pos) error("Number expected")
        return input.substring(start, pos).toDouble()
    }
    private fun skip() { while (pos < input.length && input[pos].isWhitespace()) pos++ }
    private fun take(c: Char): Boolean {
        if (pos < input.length && input[pos] == c) { pos++; return true }
        return false
    }
}
